import Person1 from '../Assets/Testimonials/mypic.png'

export const TestimonialsData = [
    // Add your testimonial data here
    {
      id: 1,
      pic:Person1,
      role: "Marketing Manager",
      companyName: "Company 1",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },
    {
      id: 2,
      pic:Person1,
      role: "Marketing Manager",
      companyName: "Company 2",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },
    {
      id: 3,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 3",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },
    {
      id: 4,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 4",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },
    {
      id: 5,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 5",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },{
      id: 6,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 6",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },{
      id: 7,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 7",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },{
      id: 8,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 8",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },{
      id: 9,
      pic:Person1,

      role: "Marketing Manager",
      companyName: "Company 9",
      content: "They communicated smoothly and were always available. Customers can expect a cost-effective and effective team.",
      rating: '5.0',
    },
    // Add more testimonial data as needed
  ];